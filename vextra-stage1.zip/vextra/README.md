# Vextra Client (Stage 1)
Target: Minecraft 1.21.11, Java 21, Fabric Loader 0.17.3+, Fabric API 0.141.5+1.21.11.
Build: `gradle wrapper` once, then `./gradlew build` -> build/libs/vextra-client-0.1.0.jar
Install: put the JAR and Fabric API in your mods folder.
Stage 1 modules: FPS, CPS (L/R), Coordinates, Sprint status. Config: config/vextra/config.json
