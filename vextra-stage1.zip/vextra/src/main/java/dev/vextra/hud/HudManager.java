package dev.vextra.hud;

import dev.vextra.VextraClient;
import dev.vextra.config.VextraConfig;
import dev.vextra.module.HudModule;
import dev.vextra.module.Modules;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

/**
 * All version-sensitive rendering lives in this single file so API drift
 * between Minecraft releases is fixed in one place.
 */
public final class HudManager {
    public static void init() {
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.MISC_OVERLAYS,
            Identifier.fromNamespaceAndPath(VextraClient.ID, "hud"),
            (graphics, tickCounter) -> render(graphics));
    }

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;
        for (HudModule m : Modules.ALL) {
            m.frame(mc);
            VextraConfig.ModuleSettings s = m.settings();
            if (!s.enabled) continue;
            String text = m.text(mc);
            if (text == null) continue;

            int w = mc.font.width(text), h = mc.font.lineHeight, p = s.padding;
            int a = Math.round(Math.clamp(s.bgOpacity, 0f, 1f) * 255f);
            int bg = (a << 24) | (s.bgColor & 0xFFFFFF);

            g.pose().pushMatrix();
            g.pose().translate(s.x, s.y);
            g.pose().scale(s.scale, s.scale);
            g.fill(0, 0, w + p * 2, h + p * 2, bg);
            g.drawString(mc.font, text, p, p, s.textColor, true);
            g.pose().popMatrix();
        }
    }
    private HudManager() {}
}
