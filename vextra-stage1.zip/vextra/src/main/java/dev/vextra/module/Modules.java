package dev.vextra.module;

import net.minecraft.client.Minecraft;

import java.util.List;

public final class Modules {
    public static final List<HudModule> ALL = List.of(
        new HudModule("fps", "FPS", 4, 4) {
            @Override public String text(Minecraft mc) { return mc.getFps() + " FPS"; }
        },
        new HudModule("cps", "CPS", 4, 24) {
            private boolean lDown, rDown;
            private final long[] l = new long[64], r = new long[64];
            private int li, ri;
            private int lc, rc;
            private long lastCount;

            @Override public void frame(Minecraft mc) {
                long now = System.currentTimeMillis();
                boolean ld = mc.mouseHandler.isLeftPressed(), rd = mc.mouseHandler.isRightPressed();
                if (ld && !lDown) l[li++ & 63] = now;
                if (rd && !rDown) r[ri++ & 63] = now;
                lDown = ld; rDown = rd;
                if (now - lastCount >= 100) { // recount 10x/sec, not every frame
                    lastCount = now;
                    lc = count(l, now); rc = count(r, now);
                }
            }
            private static int count(long[] a, long now) {
                int n = 0;
                for (long t : a) if (t != 0 && now - t <= 1000) n++;
                return n;
            }
            @Override public String text(Minecraft mc) { return lc + " | " + rc + " CPS"; }
        },
        new HudModule("coords", "Coordinates", 4, 44) {
            @Override public String text(Minecraft mc) {
                if (mc.player == null) return null;
                return String.format("XYZ %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            }
        },
        new HudModule("sprint", "Sprint Status", 4, 64) {
            @Override public String text(Minecraft mc) {
                return mc.player != null && mc.player.isSprinting() ? "Sprinting" : "Walking";
            }
        }
    );
    private Modules() {}
}
