package dev.vextra.module;

import dev.vextra.config.VextraConfig;
import net.minecraft.client.Minecraft;

/** A text-panel HUD module. Subclasses only supply text; layout/style comes from config. */
public abstract class HudModule {
    public final String id, displayName;
    public final int defX, defY;

    protected HudModule(String id, String displayName, int defX, int defY) {
        this.id = id; this.displayName = displayName; this.defX = defX; this.defY = defY;
    }

    public VextraConfig.ModuleSettings settings() { return VextraConfig.get().of(id, defX, defY); }

    /** Return the text to draw, or null to draw nothing this frame. Must be allocation-light. */
    public abstract String text(Minecraft mc);

    /** Called once per rendered frame regardless of visibility (for input sampling). */
    public void frame(Minecraft mc) {}
}
