package dev.vextra.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.*;
import java.util.LinkedHashMap;
import java.util.Map;

/** Persistent config. Atomic writes; corrupt files are backed up, never crash the game. */
public final class VextraConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("vextra");
    private static final Path FILE = DIR.resolve("config.json");
    private static VextraConfig instance = new VextraConfig();

    /** Per-module settings keyed by module id. */
    public Map<String, ModuleSettings> modules = new LinkedHashMap<>();

    public static final class ModuleSettings {
        public boolean enabled = true;
        public int x = 4, y = 4;
        public float scale = 1.0f;
        public int textColor = 0xFFFFFFFF;
        public int bgColor = 0xFF000000;
        public float bgOpacity = 0.4f;   // 0..1
        public int padding = 3;
    }

    public static VextraConfig get() { return instance; }

    public ModuleSettings of(String id, int defX, int defY) {
        return modules.computeIfAbsent(id, k -> {
            ModuleSettings s = new ModuleSettings();
            s.x = defX; s.y = defY;
            return s;
        });
    }

    public static void load() {
        try {
            Files.createDirectories(DIR);
            if (Files.exists(FILE)) {
                VextraConfig loaded = GSON.fromJson(Files.readString(FILE), VextraConfig.class);
                if (loaded != null && loaded.modules != null) instance = loaded;
            }
        } catch (Exception e) {
            try { if (Files.exists(FILE)) Files.move(FILE, DIR.resolve("config.broken.json"), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ignored) {}
            instance = new VextraConfig();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(DIR);
            Path tmp = DIR.resolve("config.json.tmp");
            Files.writeString(tmp, GSON.toJson(instance));
            Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception ignored) {}
    }

    public static void resetAll() { instance = new VextraConfig(); save(); }
}
